# Fase 8.2 — Integridade do lockfile e validação da árvore candidata

**Repositório:** `zapproions-tech/zappro`  
**Branch isolada:** `audit/fase8-sequelize6-migration-20261009`  
**SHA final da branch:** `cdbcdc8ca9200897bb0666c7f3641d1e5c3e23e6`  
**Execução final:** [GitHub Actions #37929898295](https://github.com/zapproions-tech/zappro/actions/runs/37929898295) — `completed / success`  
**Decisão desta fase:** **ÁRVORE CANDIDATA ÍNTEGRA**, usando geração de lockfile sem `--legacy-peer-deps`. Isso não aprova nem conclui a migração funcional Sequelize 5 → 6.

## 1. Escopo e segurança

- A verificação ocorreu em runners descartáveis do GitHub Actions e em diretórios temporários (`/tmp/fase82-candidate` e `/tmp/fase82-candidate-peer-aware`).
- A cópia baseline foi instalada com `npm ci`; a árvore original foi verificada antes de criar candidatos.
- Cada candidato alterou somente as versões diretas `sequelize` e `sequelize-typescript` no `package.json` temporário. Não houve alteração direta de Baileys, `sharp` ou outras dependências.
- Não foram executados build TypeScript, testes de aplicação, migrations ou seeds no workflow Fase 8.2.
- Nenhuma alteração foi feita em `backend/package.json`, `backend/package-lock.json`, código funcional, banco operacional ou VPS.
- `main` permanece em `2d31437f6f4b46fd75951be8fbd45d7f87262002`; PR #50 permanece aberto e não mesclado.

## 2. Ambiente e hash imutável

| Item | Valor |
|---|---|
| Node | `v22.23.3` |
| npm | `10.9.9` |
| Plataforma | `linux/x64` |
| `npm config get omit` | vazio |
| `npm config get optional` | `null` |
| `backend/package.json` SHA-256 | `0df4059fdd1c875d28a5ee27290acac83319da41801eebe3e8fd2ee2503cf2a7` |
| `backend/package-lock.json` SHA-256 antes | `d4758bc5aa5c2abba125f538d408da101644334fa9977caf816881e16606c88e` |
| `backend/package-lock.json` SHA-256 depois | `d4758bc5aa5c2abba125f538d408da101644334fa9977caf816881e16606c88e` |
| Integridade do lockfile original | **Confirmada — hashes iguais** |

O lockfile original é `lockfileVersion: 3`. A baseline original declarou e instalou `sequelize@5.22.5` e `sequelize-typescript@1.1.0`.

## 3. Causa comprovada da ausência de `sharp`

A inspeção do `package-lock.json` original, dos metadados efetivamente publicados de `baileys@7.0.0-rc13` e da árvore instalada confirmou:

- Baileys declara `sharp: "*"` em `peerDependencies`.
- O metadado `peerDependenciesMeta` marca `audio-decode`, `jimp` e `link-preview-js` como opcionais, mas **não marca `sharp` como opcional**.
- O lockfile original contém `node_modules/sharp@0.35.5` com `peer: true`.
- Na plataforma `linux/x64`, a baseline `npm ls --all` retorna `0` e a árvore mostra `baileys@7.0.0-rc13 → sharp@0.35.5`.

A primeira estratégia regenerava o lockfile usando `--legacy-peer-deps`. Mesmo acrescentando `--include=optional`, a nova árvore não continha nenhuma entrada de `sharp`. O `npm ci` candidato retornou `0`, mas `npm ls --all` retornou `1` com a mensagem literal `missing: sharp@*, required by baileys@7.0.0-rc13`.

**Conclusão causal:** a ausência não era uma omissão legítima de binário específica da plataforma. A estratégia `--legacy-peer-deps` ignorava a resolução de peer dependencies e produzia um lockfile que descartava o peer exigido por Baileys. Não se instalou `sharp` manualmente nem se alterou o manifesto do projeto para contornar o erro.

## 4. Estratégias e códigos de saída

### Baseline original

| Comando | Código de saída |
|---|---:|
| `npm ci --foreground-scripts` | `0` |
| `npm ls --all --json` | `0` |
| `npm ls baileys sharp --all` | `0` |

### Estratégia A — lockfile gerado com `--legacy-peer-deps` (rejeitada)

Comando de geração:

```bash
npm install --package-lock-only --ignore-scripts --legacy-peer-deps --include=optional --no-audit --no-fund
```

| Comando | Código de saída |
|---|---:|
| Geração do lockfile | `0` |
| `npm ci --legacy-peer-deps --include=optional --foreground-scripts` | `0` |
| `npm ls --all --json` | `1` |
| `npm ls baileys sharp sequelize sequelize-typescript --all` | `0` (árvore resumida não expôs a falta; o `npm ls --all` completo detectou) |

SHA-256 do lockfile candidato A: `919302016fd5b9e5f521960a9f788796a704bcd02e7fa1b696aa1f2e84ec56dc`. O lockfile A não contém `node_modules/sharp`; portanto, não atende ao critério de integridade.

### Estratégia B — resolução normal de peer dependencies (aceita para diagnóstico)

Comando de geração:

```bash
npm install --package-lock-only --ignore-scripts --include=optional --no-audit --no-fund
```

Foi removido somente `--legacy-peer-deps`; as versões diretas do ORM continuaram exatamente `sequelize@6.37.8` e `sequelize-typescript@2.1.6`.

| Comando | Código de saída |
|---|---:|
| Geração do lockfile B | `0` |
| `npm ci --include=optional --foreground-scripts` | `0` |
| `npm ls --all --json` | `0` |
| `npm ls baileys sharp sequelize sequelize-typescript --all` | `0` |

O `npm ls --all` completo não produziu stderr. A árvore-chave instalada confirma:

```text
baileys@7.0.0-rc13
└── sharp@0.35.5
sequelize-typescript@2.1.6
└── sequelize@6.37.8 deduped
sequelize@6.37.8
```

O lockfile candidato B contém `node_modules/sharp` e os pacotes específicos da plataforma necessários. SHA-256 do lockfile B: `d7dccc529424191c9067d2ab34e304065eff7368e1fb397c4d395a0c4d42aac1`.

## 5. Comparação das árvores

A comparação da baseline com a Estratégia B identificou **19 diferenças de caminho/versão** no grafo lógico:

- **3 entradas diretamente relacionadas ao ORM** (inclui o caminho de `sequelize` deduplicado sob `sequelize-typescript`).
- **16 entradas transitivas relacionadas ao ORM/TypeScript**.
- **0 diferenças classificadas como transitivas não ORM**.
- **0 diferenças em `sharp` ou em pacotes opcionais/plataforma** na comparação baseline ↔ B.

As transitivas do ORM que mudaram incluem `inflection`, `retry-as-promised`, `semver`, `sequelize-pool`, `wkx` e dependências de tipos. Essas alterações decorrem das novas versões de Sequelize/sequelize-typescript e estão listadas no arquivo `fase82-tree-delta.csv` e no log JSON integral do artefato. Não foi observada atualização direta alheia ao ORM.

A Estratégia A mostrou 54 diferenças de caminho, incluindo a remoção de `sharp` e da sua árvore; por isso foi rejeitada, apesar de `npm ci` retornar `0`.

## 6. Dependências opcionais e plataforma

A ausência de entradas específicas de outras plataformas para os binários nativos de Sharp não foi usada como sinal de falha: a avaliação foi feita em `linux/x64`, e a árvore válida B contém `sharp@0.35.5` e suas dependências resolvidas para essa plataforma. Já a ausência do próprio pacote `sharp` na Estratégia A foi uma falha real de peer dependency, confirmada pelo `npm ls --all` e pelos metadados de Baileys.

## 7. Reprodutibilidade e artefatos

A execução final foi [GitHub Actions #37929898295](https://github.com/zapproions-tech/zappro/actions/runs/37929898295), SHA `cdbcdc8ca9200897bb0666c7f3641d1e5c3e23e6`, conclusão `success`. Ela guardou comandos, versões, saída integral de `npm ci`, stderr de `npm ls`, status codes, hashes dos lockfiles candidatos e comparação das árvores.

- Artefato da Estratégia A e baseline: `fase82-lock-integrity.zip` (execução #37929408821).
- Artefato final com as duas estratégias: `fase82-lock-integrity-peer-aware.zip` (execução #37929898295).
- Artefatos Fase 8.1 anteriores foram preservados dentro do pacote ZIP consolidado.

Um workflow intermediário de diagnóstico teve erro de definição antes de executar etapas; foi corrigido em branch isolada. Não houve alteração funcional nem alteração de lockfile original. A execução final válida está vinculada acima.

## 8. Decisão e próximos passos

**Fase 8.2: concluída para integridade da árvore candidata.** A árvore candidata C pode ser avaliada com confiança quando o lockfile temporário é gerado sem `--legacy-peer-deps`, com os dois pins do ORM e a resolução normal de peers. Os critérios de instalação, `npm ls --all`, dependências de plataforma e imutabilidade do lockfile original foram atendidos.

**A migração funcional continua AMARELA e não foi iniciada.** Não foram compilados os 107 erros TypeScript nesta fase; não foram executados testes funcionais nem migrations/rollback para a candidata. O próximo passo autorizado deve ser uma fase separada, corrigindo erros TypeScript em grupos pequenos, e depois validar associações, transações, migrations com rollback e isolamento multiempresa. O resultado de árvore íntegra não comprova compatibilidade funcional do sistema.
