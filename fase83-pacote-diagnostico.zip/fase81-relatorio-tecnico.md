# Fase 8.1 — Diagnóstico controlado Sequelize 5 → 6

## Estado e escopo

- Branch de auditoria: `audit/fase8-sequelize6-migration-20261009`.
- SHA da execução 2: `f7453e3a8255c8979bc8631adb6fed45891b4358`.
- SHA atual do workflow de diagnóstico controlado: `7b860fda00db0f1ca0b3fee7e3b1f9a9c66a57aa`.
- Execução controlada anterior: [GitHub Actions 37887163516](https://github.com/zapproions-tech/zappro/actions/runs/37887163516), concluída.
- Execução com lockfiles candidatos: [GitHub Actions 37888754009](https://github.com/zapproions-tech/zappro/actions/runs/37888754009), job terminou, mas `npm ls` reportou inconsistências nos candidatos.
- Nenhuma alteração funcional, `package.json`, `package-lock.json`, `main`, VPS ou PR #50.
- As classificações por erro no CSV preservam a mensagem original e marcam causa-raiz como hipótese até os braços A/B/C serem comparados.

## Baseline comprovado (execução 37886132686)

| Comando | Código | Evidência |
|---|---:|---|
| `npm ci` | 0 (etapa concluída) | Instalação do lockfile original |
| `npm run build` | 0 | Log baseline sem erro TS |
| `npm run lint` | 2 | Configuração `prettier/@typescript-eslint` não encontrada/mesclada no `eslint-config-prettier` |
| `npm test -- --runInBand` | 1 | 84 testes passaram, 1 falhou; 20 suítes passaram, 1 falhou, 27 totais (21 contabilizadas) |
| `npm audit --json` | 1 | 90 vulnerabilidades: 2 críticas, 69 altas, 14 moderadas, 5 baixas |
| Instalação candidata | 0 | Adicionou 19, removeu 15, alterou 139 pacotes |
| `npm ls sequelize sequelize-typescript typescript --all` | 1 | Sequelize 6.37.8 e sequelize-typescript 2.1.6 invalidam as declarações de raiz 5.22.5 e 1.1.0 |
| Build candidato | 2 | 107 erros TS em 53 arquivos |

## Fuso horário — causa identificada para a falha do teste

O workflow exporta `APP_TIME_ZONE=America/Porto_Velho`. `backend/src/bootstrap.ts` define `APP_TIME_ZONE = process.env.APP_TIME_ZONE || "America/Cuiaba"` e atribui `process.env.TZ = APP_TIME_ZONE`. A configuração de banco importa esse valor. O teste `appTimeZone.spec.ts` espera `America/Cuiaba`, mas só substitui `TZ` por `Europe/Berlin` no subprocesso e herda `APP_TIME_ZONE` do ambiente pai. Assim, `APP_TIME_ZONE=America/Porto_Velho` prevalece sobre o default Cuiabá. O resultado recebido é coerente com a configuração do workflow. Não se deve mudar o esperado para Porto Velho sem decidir a zona de negócio; o teste deve declarar explicitamente a zona que quer validar e o workflow deve evitar conflitar com essa intenção.

## ESLint — causa identificada

`backend/.eslintrc.json` estende `prettier/@typescript-eslint`. O lockfile fixa `eslint-config-prettier@8.10.2` e `eslint@8.57.1`; o log mostra que `prettier/@typescript-eslint` foi incorporado a `prettier` no eslint-config-prettier 8.0. A correção mínima proposta é remover somente a extensão obsoleta e validar `npm run lint` isoladamente, sem misturar com Sequelize. Ainda não aplicada nesta fase.

## Interpretação da árvore experimental

O manifesto declara Sequelize `5.22.5` e sequelize-typescript `1.1.0`. O comando experimental instalou `sequelize@6.37.8` e `sequelize-typescript@2.1.6` com `--no-save --package-lock=false`; por isso os pacotes efetivos não correspondem às versões de raiz declaradas e `npm ls` os marca `invalid`. Isso não demonstra pacote corrompido; demonstra que `node_modules` é um experimento deliberadamente divergente do manifesto/lockfile. O lockfile original contém TypeScript `4.9.5`, portanto não há evidência de que o TypeScript tenha sido atualizado de versão durante esse candidato. O `npm install` informou 139 pacotes alterados, mas os dois primeiros workflows não registraram árvore completa antes/depois, então não é possível atribuir individualmente essas 139 mudanças com evidência histórica. A execução controlada 3 capturou árvores completas com `npm ci` antes de cada braço, mas a instalação sem lockfile mudou 165 nomes de pacotes da mesma forma nos três braços; por isso ela não foi suficiente para uma comparação limpa. A execução 5 criou cópias temporárias com `package.json` candidato e lockfile correspondente, executou `npm ci` em cada cópia e capturou as árvores. O `package-lock.json` original do repositório não foi modificado; seu SHA permaneceu `d4758bc5aa5c2abba125f538d408da101644334fa9977caf816881e16606c88e`.

Na execução com lockfiles candidatos, o delta de árvore por caminho foi 51 (A), 38 (B) e 54 (C). Contudo, os três `npm ls --all` terminaram com código 1 porque a árvore candidata ficou sem `sharp@*`, exigido por `baileys@7.0.0-rc13`; A e B também reportam `sequelize` inválido devido à incompatibilidade intencional de uma das duas bibliotecas com a versão isolada. Isso indica que o lockfile candidato gerado por npm reescreveu/removeu entradas opcionais alheias ao ORM. Os builds foram executados mesmo com esse alerta, mas a árvore ainda não pode ser declarada íntegra.

Builds por braço, com manifests e lockfiles temporários próprios: A (Sequelize 6.37.8 + sequelize-typescript 1.1.0) produziu 1.592 erros em 478 arquivos; B (Sequelize 5.22.5 + sequelize-typescript 2.1.6) produziu 3.577 erros em 404 arquivos; C (par 6.37.8 + 2.1.6) produziu 107 erros em 53 arquivos. O par reduz drasticamente as incompatibilidades das versões isoladas, sugerindo forte dependência de compatibilidade entre as duas bibliotecas. Na comparação exata arquivo/linha/código/mensagem, 7 erros do par também aparecem no braço A — são assinaturas de migração `TS2554`; os outros 100 não aparecem exatamente nos braços A/B isolados e devem ser tratados como efeitos da combinação ou dos tipos, ainda sem causa-raiz definitiva.

A baseline executou migrations `up` e seeds no PostgreSQL descartável, mas o teste Jest falhou. Não há evidência de que `posttest`/`db:migrate:undo:all` tenha sido executado após a falha; portanto o rollback não está validado por esta execução. O container era descartável, então não há banco operacional envolvido.

## Auditoria de segurança

O `npm audit` do baseline leu o manifesto/lockfile original e registrou 90 vulnerabilidades. Entre as críticas, `sequelize` aponta recomendações para 6.37.8 e `sequelize-typescript` para 2.1.6. A auditoria executada após o `npm install` experimental no primeiro workflow não é prova de que a árvore candidata está limpa: o manifesto/lockfile não foi atualizado intencionalmente. A auditoria não deve ser interpretada como validação de segurança da migração candidata.

## Erros TypeScript — resumo do log original

- `TS2322`: 65
- `TS2345`: 31
- `TS2554`: 7
- `TS2416`: 2
- `TS2365`: 1
- `TS2769`: 1

Inventário completo, uma linha por erro, com código, arquivo, linha, mensagem original, categoria, hipótese de causa-raiz, correção mínima proposta e testes: `fase81-typescript-error-inventory.csv`. Todas as causas-raiz são explicitamente marcadas como hipóteses. A coluna de comparação dos braços indica se cada mensagem exata reaparece no braço A, B ou somente no par; isso é evidência de atribuição, não prova definitiva da causa sem análise do tipo/API e teste focalizado.

## Decisão e critérios

**AMARELO — executar mais um experimento técnico; não iniciar migração funcional.** Os resultados dos três braços são úteis para mostrar que as duas bibliotecas precisam ser atualizadas em conjunto, mas os lockfiles candidatos ainda perdem `sharp@*` e `npm ls` não valida as árvores. O próximo passo é corrigir apenas o procedimento de geração/instalação do lockfile temporário e provar que o baseline de dependências não relacionadas permanece intacto. A viabilidade só pode ser avaliada após build, testes relevantes, rollback de migrations, associações, transações e isolamento multiempresa. Rollback do experimento é descartar as cópias temporárias e usar o lockfile original; nenhum artefato operacional foi alterado.
